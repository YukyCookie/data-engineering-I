# DE1_Project

ex.py usage:

python3 ex.py [FLAGS] <HDF5 file> <OPT: song idx> <OPT: getter>
  
1. Single file:

  python3 ex.py TRAGAAF128F9338911.h5 <br>
  python3 ex.py -summary TRAGAAF128F9338911.h5 <br>
  python3 ex.py TRAGAAF128F9338911.h5 0 tempo <br>

2. Directory

  python3 ex.py -dir ./millionsongsubset/A/G/A/ <br>

